# Forex Signal Bot

This is a simulated version of a Forex signal bot that sends alerts to your Telegram using a bot token and chat ID.

## Files
- `telegram_test.py`: Send a test message to Telegram to verify your setup.
- `signal_bot_sim.py`: Sends random simulated forex signals every minute.

## Setup
1. Replace `'your_token_here'` and `'your_chat_id_here'` with your actual Telegram bot token and chat ID.
2. Run the files in Replit or any Python environment.
